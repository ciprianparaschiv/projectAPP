<?php /* Smarty version 2.6.12, created on 2022-10-27 13:15:39
         compiled from inc/footer.tpl */ ?>
</div>
<div id="footer">&copy; 2010
</div>
<div class="clear"></div>
</div>
</body>
</html>