<?php /* Smarty version 2.6.12, created on 2012-07-23 10:06:56
         compiled from inc/footer.tpl */ ?>
</div>
<div id="footer">&copy; 2010
</div>
<div class="clear"></div>
</div>
</body>
</html>